Open Scholar Secure Player 1.2.0 - complete package

Files in this ZIP
- Open_Scholar_Secure_Player_Preview.html        The Player (for learners). Open in Chrome, Edge or Safari.
- Open_Scholar_Secure_File_Maker_Preview.html    The Maker (for publishers only). Makes .scholar and .scholarpass files.
- Open_Scholar_Secure_Player_Plugin_v1.2.0.zip   WordPress plugin. Upload in Plugins > Add New > Upload Plugin.
- Open_Scholar_Secure_Player_Development_Pack_v1.2.0.zip  Full source, tests, build scripts and developer docs.
- USER_GUIDE.md                                   How to use the Player, the Maker and the plugin.
- SHA256SUMS.txt                                  Checksums. Check each file before you use it.

Notes
- Web apps only. There is no Windows program in this package.
- Protected lessons are not protected modules. Shared .osmodule files are not protected.
- Not yet tested on real phones or inside WordPress.
